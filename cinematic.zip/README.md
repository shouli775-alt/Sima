# Cinematic (working title)

Open-source movies / series / anime app: Expo + React Native + TypeScript. Liquid Glass UI. Not endorsed by TMDB; metadata comes from TMDB, playback sources come only from user-approved providers.

## Setup
```
npx create-expo-app@latest cinematic --template tabs
# copy app/ and src/ from this folder into the project, then:
npx expo install expo-video expo-blur expo-linear-gradient expo-haptics expo-screen-orientation expo-status-bar \
  react-native-reanimated react-native-gesture-handler react-native-safe-area-context @react-native-async-storage/async-storage
npx expo start
# open with params: /player?type=movie&id=1&title=Demo
```

## Status (honest)
| Area | State |
|---|---|
| Design tokens, `Glass` (blur, specular edge, reduce-transparency fallback) | written, **not run** |
| Liquid Glass player: play/pause, ±10s, double-tap seek, droplet scrubber, subtitle cycling, error retry, next-episode, auto-hide | written, **not run** |
| Progress rules (`core.ts`: completion threshold, resume, merge) | written, **no unit tests yet** |
| Audio-track picker, fullscreen/PiP polish, cloud sync of progress | not built |
| TMDB, auth, library, add-ons, repositories, Supabase schema/RLS, CI, docs | not started (Phases 3–8) |

Nothing has been compiled or run on a device: the build sandbox had no network access, so dependencies could not be installed or type-checked. API names follow expo-video, Reanimated and Gesture Handler docs and may need small version fixes.

The demo provider uses Blender's Big Buck Bunny sample and ignores the requested title.
