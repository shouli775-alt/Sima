export const tokens = {
  color: {
    ink: '#07090D',
    text: '#F5F7FA',
    textDim: 'rgba(245,247,250,0.64)',
    edge: 'rgba(255,255,255,0.28)',
    fill: 'rgba(255,255,255,0.08)',
    flat: 'rgba(18,22,30,0.94)', // reduce-transparency fallback
    danger: '#FF6B6B',
  },
  radius: { sm: 12, md: 20, lg: 28, pill: 999 },
  space: { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 },
  blur: { thin: 24, regular: 40, thick: 70 },
  type: { title: 17, caption: 12, time: 13 },
  motion: { fast: 140, base: 240, slow: 420, spring: { damping: 18, stiffness: 220, mass: 0.8 } },
} as const;
