import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, I18nManager, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { interpolateColor, runOnJS, useAnimatedStyle, useDerivedValue, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Glass, useReduceMotion } from '../ui/Glass';
import { tokens as t } from '../theme/tokens';
import { PLAYBACK, type ResolvedSource } from './core';

const L = I18nManager.isRTL
  ? { close: 'إغلاق', play: 'تشغيل', pause: 'إيقاف مؤقت', back: 'رجوع 10 ثوانٍ', fwd: 'تقديم 10 ثوانٍ', subs: 'الترجمة', next: 'الحلقة التالية', fail: 'تعذّر تشغيل هذا المصدر', retry: 'إعادة المحاولة' }
  : { close: 'Close', play: 'Play', pause: 'Pause', back: 'Back 10 seconds', fwd: 'Forward 10 seconds', subs: 'Subtitles', next: 'Next episode', fail: "This source couldn't be played", retry: 'Try again' };

const fmt = (s: number) => {
  s = Math.max(0, Math.floor(s));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60, p = (n: number) => String(n).padStart(2, '0');
  return h ? `${h}:${p(m)}:${p(x)}` : `${m}:${p(x)}`;
};
const clamp01 = (v: number) => { 'worklet'; return Math.min(1, Math.max(0, v)); };

type Props = {
  source: ResolvedSource; title: string; subtitle?: string; startAt?: number; autoPlayNext?: boolean;
  onProgress: (position: number, duration: number | undefined, reason: 'tick' | 'pause' | 'exit') => void;
  onNext?: () => void; onClose: () => void;
};

export function LiquidGlassPlayer({ source, title, subtitle, startAt = 0, autoPlayNext, onProgress, onNext, onClose }: Props) {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const reduce = useReduceMotion();
  const [playing, setPlaying] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'readyToPlay' | 'error'>('loading');
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(0);
  const [shown, setShown] = useState(true);
  const [touch, setTouch] = useState(0);
  const scrubbing = useRef(false);
  const last = useRef({ pos: 0, dur: 0 });
  const resumeFrom = useRef(startAt);
  const report = useRef(onProgress); report.current = onProgress;
  const next = useRef(onNext); next.current = onNext;
  const emit = (r: 'tick' | 'pause' | 'exit') => report.current(last.current.pos, last.current.dur || undefined, r);

  const toPlayerSource = () => ({ uri: source.uri, headers: source.headers, contentType: source.contentType });
  const player = useVideoPlayer(toPlayerSource(), (p) => { p.timeUpdateEventInterval = 0.5; p.play(); });

  useEffect(() => {
    const subs = [
      player.addListener('statusChange', ({ status: s }) => {
        setStatus(s);
        if (s === 'readyToPlay') {
          setDur(player.duration);
          if (resumeFrom.current > 0) player.currentTime = resumeFrom.current;
          resumeFrom.current = 0;
        }
      }),
      player.addListener('playingChange', ({ isPlaying }) => { setPlaying(isPlaying); if (!isPlaying) emit('pause'); }),
      player.addListener('timeUpdate', ({ currentTime }) => {
        last.current = { pos: currentTime, dur: player.duration };
        if (!scrubbing.current) setPos(currentTime);
      }),
      player.addListener('playToEnd', () => { last.current.pos = last.current.dur; emit('exit'); if (autoPlayNext) next.current?.(); }),
    ];
    return () => subs.forEach((x) => x.remove());
  }, [player, autoPlayNext]);

  useEffect(() => {
    const id = setInterval(() => { if (player.playing) emit('tick'); }, PLAYBACK.saveEveryMs);
    return () => { clearInterval(id); emit('exit'); };
  }, [player]);

  useEffect(() => {
    if (!shown || !playing) return;
    const id = setTimeout(() => { if (!scrubbing.current) setShown(false); }, 3500);
    return () => clearTimeout(id);
  }, [shown, playing, touch]);

  const ui = useSharedValue(1);
  useEffect(() => { ui.value = withTiming(shown ? 1 : 0, { duration: reduce ? 0 : t.motion.base }); }, [shown, reduce]);
  const uiStyle = useAnimatedStyle(() => ({ opacity: ui.value, transform: [{ translateY: reduce ? 0 : (1 - ui.value) * 12 }] }));

  const poke = () => { setShown(true); setTouch((n) => n + 1); };
  const tick = () => Haptics.selectionAsync().catch(() => {});
  const toggle = () => { tick(); poke(); player.playing ? player.pause() : player.play(); };
  const skip = (s: number) => { tick(); poke(); player.seekBy(s); };
  const seekTo = (sec: number) => { tick(); player.currentTime = sec; setPos(sec); poke(); };
  const cycleSubs = () => {
    const tracks = player.availableSubtitleTracks;
    if (!tracks.length) return;
    const i = tracks.findIndex((x) => x.id === player.subtitleTrack?.id);
    player.subtitleTrack = i + 1 < tracks.length ? tracks[i + 1] : null;
    poke();
  };
  const retry = () => { resumeFrom.current = last.current.pos; setStatus('loading'); player.replace(toPlayerSource()); player.play(); };

  const taps = Gesture.Exclusive(
    Gesture.Tap().numberOfTaps(2).onEnd((e) => { runOnJS(skip)(e.x < width / 2 ? -10 : 10); }),
    Gesture.Tap().onEnd(() => { runOnJS(setShown)(!shown); }),
  );
  const ev = shown ? 'box-none' : 'none';

  return (
    <View style={s.root}>
      <GestureDetector gesture={taps}>
        <View style={StyleSheet.absoluteFill}>
          <VideoView player={player} style={StyleSheet.absoluteFill} nativeControls={false} contentFit="contain" allowsPictureInPicture />
        </View>
      </GestureDetector>

      {status === 'loading' && <View style={s.center} pointerEvents="none"><ActivityIndicator size="large" color={t.color.text} /></View>}

      {status === 'error' && (
        <View style={s.center}>
          <Glass intensity="thick" style={{ maxWidth: 360 }}>
            <View style={{ padding: t.space.xl, gap: t.space.lg, alignItems: 'center' }}>
              <Text style={s.title}>{L.fail}</Text>
              <Pressable accessibilityRole="button" onPress={retry} style={s.retry}><Text style={s.title}>{L.retry}</Text></Pressable>
            </View>
          </Glass>
        </View>
      )}

      <Animated.View pointerEvents={ev} style={[s.top, { paddingTop: insets.top + t.space.sm, paddingHorizontal: insets.left + t.space.lg }, uiStyle]}>
        <Btn label={L.close} onPress={onClose}><Ionicons name="close" size={22} color={t.color.text} /></Btn>
        <Glass blur={false} radius={t.radius.pill} style={{ flexShrink: 1, marginStart: t.space.md }}>
          <View style={{ paddingHorizontal: t.space.lg, paddingVertical: t.space.sm }}>
            <Text numberOfLines={1} style={s.title}>{title}</Text>
            {subtitle ? <Text numberOfLines={1} style={s.caption}>{subtitle}</Text> : null}
          </View>
        </Glass>
      </Animated.View>

      <Animated.View pointerEvents={ev} style={[s.bottom, { paddingBottom: insets.bottom + t.space.md, paddingHorizontal: Math.max(insets.left, insets.right) + t.space.lg }, uiStyle]}>
        <Glass intensity="thick" radius={t.radius.lg + 4}>
          <View style={{ padding: t.space.lg, gap: t.space.sm }}>
            <Scrubber position={pos} duration={dur} onSeek={seekTo} onScrubbing={(b) => { scrubbing.current = b; if (b) poke(); }} />
            <View style={s.transport}>
              <View style={s.side}><Btn label={L.subs} onPress={cycleSubs}><Ionicons name="text" size={20} color={t.color.text} /></Btn></View>
              <View style={s.mid}>
                <Btn label={L.back} onPress={() => skip(-10)} wide><Text style={s.title}>−10</Text></Btn>
                <Btn label={playing ? L.pause : L.play} onPress={toggle} size={64}><Ionicons name={playing ? 'pause' : 'play'} size={30} color={t.color.text} /></Btn>
                <Btn label={L.fwd} onPress={() => skip(10)} wide><Text style={s.title}>+10</Text></Btn>
              </View>
              <View style={[s.side, { alignItems: 'flex-end' }]}>
                {onNext ? <Btn label={L.next} onPress={onNext}><Ionicons name="play-skip-forward" size={20} color={t.color.text} /></Btn> : null}
              </View>
            </View>
          </View>
        </Glass>
      </Animated.View>
    </View>
  );
}

function Btn({ label, onPress, children, size = 44, wide }: { label: string; onPress: () => void; children: React.ReactNode; size?: number; wide?: boolean }) {
  return (
    <Glass blur={false} radius={t.radius.pill}>
      <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} hitSlop={8} style={{ minWidth: wide ? size + 16 : size, height: size, alignItems: 'center', justifyContent: 'center' }}>{children}</Pressable>
    </Glass>
  );
}

function Scrubber({ position, duration, onSeek, onScrubbing }: { position: number; duration: number; onSeek: (s: number) => void; onScrubbing: (b: boolean) => void }) {
  const reduce = useReduceMotion();
  const w = useSharedValue(1), x = useSharedValue(0), rest = useSharedValue(0), active = useSharedValue(0);
  const [tw, setTw] = useState(1);
  const [scrubSec, setScrubSec] = useState<number | null>(null);
  const hold = useRef(0);

  useEffect(() => { if (Date.now() > hold.current) rest.value = duration > 0 ? Math.min(1, position / duration) : 0; }, [position, duration]);

  const move = (f: number) => setScrubSec(f * duration);
  const end = (f: number) => { hold.current = Date.now() + 800; setScrubSec(null); onScrubbing(false); if (duration > 0) onSeek(f * duration); };
  const spring = (v: number) => { 'worklet'; return reduce ? v : withSpring(v, t.motion.spring); };

  const pan = Gesture.Pan().minDistance(0)
    .onBegin((e) => { x.value = clamp01(e.x / w.value); active.value = spring(1); runOnJS(onScrubbing)(true); runOnJS(move)(x.value); })
    .onUpdate((e) => { x.value = clamp01(e.x / w.value); runOnJS(move)(x.value); })
    .onFinalize(() => { rest.value = x.value; active.value = spring(0); runOnJS(end)(x.value); });

  const frac = useDerivedValue(() => (active.value > 0.001 ? x.value : rest.value));
  const track = useAnimatedStyle(() => { const h = 4 + active.value * 4; return { height: h, top: 20 - h / 2 }; });
  const fill = useAnimatedStyle(() => ({ width: frac.value * w.value }));
  const thumb = useAnimatedStyle(() => {
    const z = 14 + active.value * 20; // swells into a droplet while dragging
    return { width: z, height: z, borderRadius: z / 2, top: 20 - z / 2, transform: [{ translateX: frac.value * w.value - z / 2 }], backgroundColor: interpolateColor(active.value, [0, 1], ['rgba(255,255,255,0.95)', 'rgba(255,255,255,0.38)']) };
  });

  const shownPos = scrubSec ?? position;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: t.space.md, direction: 'ltr' }}>
      <Text style={s.time}>{fmt(shownPos)}</Text>
      <GestureDetector gesture={pan}>
        <View style={{ flex: 1, height: 40 }} onLayout={(e) => { w.value = e.nativeEvent.layout.width; setTw(e.nativeEvent.layout.width); }}>
          <Animated.View style={[s.trackBg, track]} />
          <Animated.View style={[s.trackFill, track, fill]} />
          <Animated.View style={[s.thumb, thumb]} />
          {scrubSec != null && duration > 0 && (
            <Glass blur={false} radius={14} style={{ position: 'absolute', top: -30, width: 64, left: Math.min(Math.max((scrubSec / duration) * tw - 32, 0), tw - 64) }}>
              <Text style={[s.time, { textAlign: 'center', paddingVertical: 4 }]}>{fmt(scrubSec)}</Text>
            </Glass>
          )}
        </View>
      </GestureDetector>
      <Text style={s.time}>−{fmt(Math.max(0, duration - shownPos))}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: t.color.ink },
  center: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  top: { position: 'absolute', top: 0, start: 0, end: 0, flexDirection: 'row', alignItems: 'center' },
  bottom: { position: 'absolute', bottom: 0, start: 0, end: 0 },
  transport: { flexDirection: 'row', alignItems: 'center', direction: 'ltr' },
  side: { flex: 1 },
  mid: { flexDirection: 'row', alignItems: 'center', gap: t.space.lg },
  title: { color: t.color.text, fontSize: t.type.title, fontWeight: '600' },
  caption: { color: t.color.textDim, fontSize: t.type.caption },
  time: { color: t.color.text, fontSize: t.type.time, fontVariant: ['tabular-nums'], minWidth: 44 },
  trackBg: { position: 'absolute', start: 0, end: 0, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.22)' },
  trackFill: { position: 'absolute', left: 0, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.9)' },
  thumb: { position: 'absolute', left: 0, borderWidth: 1, borderColor: t.color.edge },
  retry: { paddingHorizontal: t.space.xl, paddingVertical: t.space.md, borderRadius: t.radius.pill, backgroundColor: t.color.fill },
});
