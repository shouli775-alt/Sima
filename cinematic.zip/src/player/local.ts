import AsyncStorage from '@react-native-async-storage/async-storage';
import { progressKey, type MediaRef, type PlaybackProvider, type Progress } from './core';

export async function loadProgress(ref: MediaRef) {
  const raw = await AsyncStorage.getItem('progress:' + progressKey(ref));
  return raw ? (JSON.parse(raw) as Progress) : undefined;
}
export const saveProgress = (p: Progress) => AsyncStorage.setItem('progress:' + progressKey(p), JSON.stringify(p));

/** Test-only provider (Blender's open movie). Ignores the requested title. Real sources come from user-approved add-ons. */
export const demoProvider: PlaybackProvider = {
  id: 'demo',
  name: 'Demo (Big Buck Bunny)',
  async resolve() {
    return { providerId: 'demo', contentType: 'progressive', uri: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' };
  },
};
