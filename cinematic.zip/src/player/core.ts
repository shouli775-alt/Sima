// Pure logic, no React / native imports, so it is unit-testable.
export type MediaRef = { mediaType: 'movie' | 'tv'; tmdbId: number; season?: number; episode?: number };

export type ResolvedSource = {
  providerId: string;
  uri: string;
  headers?: Record<string, string>;
  contentType?: 'hls' | 'dash' | 'progressive' | 'smoothStreaming';
  subtitles?: { lang: string; label: string; uri: string }[];
};

export class ProviderError extends Error {
  constructor(public code: 'unavailable' | 'forbidden' | 'network' | 'unsupported', message: string) { super(message); }
}

/** Source discovery/resolution lives here, never in the player UI. Resolve only what the user may access. */
export interface PlaybackProvider {
  id: string;
  name: string;
  resolve(ref: MediaRef, signal: AbortSignal): Promise<ResolvedSource>;
}

export type Progress = MediaRef & {
  position: number; duration?: number; completed: boolean; lastWatchedAt: number; providerId?: string;
};

export const PLAYBACK = { completeAt: 0.92, minSeconds: 60, saveEveryMs: 15000, resumeRewind: 3, resumeMin: 10 };

export const progressKey = (r: MediaRef) => `${r.mediaType}:${r.tmdbId}:${r.season ?? 0}:${r.episode ?? 0}`;

/** Needs a known duration AND real watch time, so a brief early interruption never completes a title. */
export const isCompleted = (pos: number, dur?: number, cfg = PLAYBACK) =>
  !!dur && dur > 0 && pos >= cfg.minSeconds && pos / dur >= cfg.completeAt;

export const resumeAt = (p?: Progress) =>
  !p || p.completed || p.position < PLAYBACK.resumeMin ? 0 : Math.max(0, p.position - PLAYBACK.resumeRewind);

/** Conflict rule: most recent watch wins; on a tie, the furthest position wins. */
export function mergeProgress(a?: Progress, b?: Progress) {
  if (!a || !b) return a ?? b;
  if (a.lastWatchedAt !== b.lastWatchedAt) return a.lastWatchedAt > b.lastWatchedAt ? a : b;
  return a.position >= b.position ? a : b;
}
