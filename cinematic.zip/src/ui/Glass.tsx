import { useEffect, useState } from 'react';
import { AccessibilityInfo, StyleSheet, View, type ViewProps } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { tokens as t } from '../theme/tokens';

function useA11yFlag(read: 'isReduceMotionEnabled' | 'isReduceTransparencyEnabled', evt: string) {
  const [v, setV] = useState(false);
  useEffect(() => {
    AccessibilityInfo[read]?.().then(setV).catch(() => {});
    const sub = AccessibilityInfo.addEventListener(evt as any, setV as any);
    return () => sub.remove();
  }, [read, evt]);
  return v;
}
export const useReduceMotion = () => useA11yFlag('isReduceMotionEnabled', 'reduceMotionChanged');
export const useReduceTransparency = () => useA11yFlag('isReduceTransparencyEnabled', 'reduceTransparencyChanged');

type Props = ViewProps & { radius?: number; intensity?: keyof typeof t.blur; blur?: boolean };

/** Glass surface. Use blur={false} for small elements nested inside another Glass (cheaper on mid-range Android). */
export function Glass({ radius = t.radius.lg, intensity = 'regular', blur = true, style, children, ...rest }: Props) {
  const flat = useReduceTransparency();
  const abs = StyleSheet.absoluteFill;
  return (
    <View {...rest} style={[{ borderRadius: radius, overflow: 'hidden' }, style]}>
      {flat || !blur ? (
        <View style={[abs, { backgroundColor: flat ? t.color.flat : t.color.fill }]} />
      ) : (
        <BlurView intensity={t.blur[intensity]} tint="dark" experimentalBlurMethod="dimezisBlurView" style={abs} />
      )}
      <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.02)']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={abs} />
      <LinearGradient pointerEvents="none" colors={['transparent', 'rgba(255,255,255,0.5)', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ position: 'absolute', top: 0, left: radius / 2, right: radius / 2, height: 1 }} />
      <View pointerEvents="none" style={[abs, { borderRadius: radius, borderWidth: 1, borderColor: t.color.edge }]} />
      {children}
    </View>
  );
}
