import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as ScreenOrientation from 'expo-screen-orientation';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { LiquidGlassPlayer } from '../src/player/LiquidGlassPlayer';
import { isCompleted, resumeAt, type MediaRef, type ResolvedSource } from '../src/player/core';
import { demoProvider, loadProgress, saveProgress } from '../src/player/local';

export default function PlayerScreen() {
  const q = useLocalSearchParams<{ type: 'movie' | 'tv'; id: string; season?: string; episode?: string; title?: string }>();
  const router = useRouter();
  const ref = useMemo<MediaRef>(() => ({ mediaType: q.type ?? 'movie', tmdbId: Number(q.id), season: q.season ? Number(q.season) : undefined, episode: q.episode ? Number(q.episode) : undefined }), [q.type, q.id, q.season, q.episode]);
  const [state, setState] = useState<{ source?: ResolvedSource; startAt: number; error?: string }>({ startAt: 0 });

  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE).catch(() => {});
    return () => { ScreenOrientation.unlockAsync().catch(() => {}); };
  }, []);

  useEffect(() => {
    const ac = new AbortController();
    (async () => {
      try {
        const [source, saved] = await Promise.all([demoProvider.resolve(ref, ac.signal), loadProgress(ref)]);
        setState({ source, startAt: resumeAt(saved) });
      } catch (e) { if (!ac.signal.aborted) setState({ startAt: 0, error: (e as Error).message }); }
    })();
    return () => ac.abort();
  }, [ref]);

  const onProgress = useCallback((position: number, duration: number | undefined) => {
    if (!state.source || position < 1) return;
    saveProgress({ ...ref, position, duration, completed: isCompleted(position, duration), lastWatchedAt: Date.now(), providerId: state.source.providerId }).catch(() => {});
  }, [ref, state.source]);

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#07090D' }}>
      <StatusBar hidden />
      {state.source ? (
        <LiquidGlassPlayer source={state.source} title={q.title ?? 'Now playing'} startAt={state.startAt} onProgress={onProgress} onClose={() => router.back()} />
      ) : (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          {state.error ? <Text style={{ color: '#fff' }}>{state.error}</Text> : <ActivityIndicator color="#fff" />}
        </View>
      )}
    </GestureHandlerRootView>
  );
}
