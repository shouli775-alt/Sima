const API_BASE='https://api.themoviedb.org/3';
const token=process.env.EXPO_PUBLIC_TMDB_ACCESS_TOKEN;
export type MediaItem={id:number;media_type?:string;title?:string;name?:string;overview?:string;vote_average?:number;release_date?:string;first_air_date?:string;poster_path?:string|null;backdrop_path?:string|null};
type Page<T>={page:number;results:T[];total_pages:number};
export async function tmdbGet<T>(path:string,params:Record<string,string>={}):Promise<T>{if(!token)throw new Error('TMDB token is not configured');const u=new URL(`${API_BASE}${path}`);Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));const r=await fetch(u.toString(),{headers:{Authorization:`Bearer ${token}`,Accept:'application/json'}});if(!r.ok)throw new Error(`TMDB request failed: ${r.status}`);return r.json() as Promise<T>}
export const getTrending=(language='ar')=>tmdbGet<Page<MediaItem>>('/trending/all/week',{language});
export const searchMovies=(query:string,language='ar')=>tmdbGet<Page<MediaItem>>('/search/movie',{query,language,include_adult:'false'});
export const getMovieDetails=(id:number,language='ar')=>tmdbGet<MediaItem>(`/movie/${id}`,{language});
