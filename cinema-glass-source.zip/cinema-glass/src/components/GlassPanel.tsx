import type { ReactNode } from 'react';
import { View, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
export function GlassPanel({children}:{children:ReactNode}) {
  return <View style={s.shell}><BlurView tint="dark" intensity={28} style={StyleSheet.absoluteFill}/><View style={s.inner}>{children}</View></View>;
}
const s=StyleSheet.create({shell:{overflow:'hidden',borderRadius:22,borderWidth:1,borderColor:'rgba(255,255,255,0.14)',backgroundColor:'rgba(20,24,36,0.72)'},inner:{padding:16}});
