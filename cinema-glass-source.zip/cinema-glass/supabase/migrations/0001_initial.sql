create table public.library_items (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 tmdb_id integer not null,
 media_type text not null check (media_type in ('movie','tv')),
 status text not null default 'watchlist' check (status in ('watchlist','watching','completed','dropped')),
 is_favorite boolean not null default false,
 created_at timestamptz not null default now(),
 unique(user_id,tmdb_id,media_type)
);
create table public.watch_progress (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 tmdb_id integer not null,
 media_type text not null check (media_type in ('movie','tv')),
 season_number integer,
 episode_number integer,
 position_seconds double precision not null default 0 check(position_seconds >= 0),
 duration_seconds double precision,
 source_id text,
 completed boolean not null default false,
 updated_at timestamptz not null default now()
);
create unique index progress_movie_unique on public.watch_progress(user_id,tmdb_id,media_type) where media_type='movie';
create unique index progress_episode_unique on public.watch_progress(user_id,tmdb_id,media_type,season_number,episode_number) where media_type='tv';
create table public.addon_installations (id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,manifest_url text not null,addon_id text,addon_name text,enabled boolean not null default true,config jsonb not null default '{}'::jsonb,created_at timestamptz not null default now(),unique(user_id,manifest_url));
create table public.repositories (id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,repository_url text not null,repository_name text,enabled boolean not null default true,created_at timestamptz not null default now(),unique(user_id,repository_url));
alter table public.library_items enable row level security;
alter table public.watch_progress enable row level security;
alter table public.addon_installations enable row level security;
alter table public.repositories enable row level security;
create policy "library owner" on public.library_items for all using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "progress owner" on public.watch_progress for all using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "addon owner" on public.addon_installations for all using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "repository owner" on public.repositories for all using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
