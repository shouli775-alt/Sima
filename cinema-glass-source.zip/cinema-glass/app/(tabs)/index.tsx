import { useEffect, useState } from 'react';
import { ScrollView, Text, View, ActivityIndicator } from 'react-native';
import { GlassPanel } from '../../src/components/GlassPanel';
import { getTrending, type MediaItem } from '../../src/services/tmdb/client';
const bg='#080A10', white='#F5F7FF', muted='#A5ADC2';
export default function Home(){
 const [items,setItems]=useState<MediaItem[]>([]); const [loading,setLoading]=useState(false); const [error,setError]=useState('');
 useEffect(()=>{let live=true; setLoading(true); getTrending().then(x=>{if(live)setItems(x.results??[])}).catch(()=>{if(live)setError('أضف إعداد TMDB في ملف البيئة لعرض الكتالوج الحقيقي.')}).finally(()=>{if(live)setLoading(false)}); return()=>{live=false}},[]);
 return <ScrollView style={{flex:1,backgroundColor:bg}} contentContainerStyle={{padding:20,paddingTop:54,gap:18}}>
  <Text style={{color:muted,textAlign:'right',fontSize:13}}>عالمك السينمائي</Text><Text style={{color:white,textAlign:'right',fontSize:32,fontWeight:'800'}}>سينما جلاس</Text>
  <GlassPanel><Text style={{color:white,textAlign:'right',fontSize:21,fontWeight:'700'}}>اكتشف قصتك القادمة</Text><Text style={{color:muted,textAlign:'right',marginTop:8,lineHeight:22}}>الأفلام والمسلسلات والأنمي في تجربة واحدة.</Text></GlassPanel>
  <Text style={{color:white,textAlign:'right',fontSize:20,fontWeight:'700'}}>الرائج الآن</Text>
  {loading&&<ActivityIndicator color="#fff"/>}{error!==''&&<Text style={{color:'#F5C16C',textAlign:'right'}}>{error}</Text>}
  {items.map(item=><GlassPanel key={`${item.media_type??'title'}-${item.id}`}><Text style={{color:white,textAlign:'right',fontSize:16,fontWeight:'700'}}>{item.title??item.name??'بدون عنوان'}</Text><Text style={{color:muted,textAlign:'right',marginTop:6}}>{item.release_date??item.first_air_date??'—'}  ·  ★ {Number(item.vote_average??0).toFixed(1)}</Text><Text style={{color:muted,textAlign:'right',marginTop:8}} numberOfLines={3}>{item.overview||'لا يوجد وصف متاح.'}</Text></GlassPanel>)}
  {!loading&&!items.length&&!error&&<View><Text style={{color:muted,textAlign:'right'}}>لا توجد نتائج حالياً.</Text></View>}
 </ScrollView>
}
