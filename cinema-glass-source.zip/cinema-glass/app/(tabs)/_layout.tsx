import { Tabs } from 'expo-router';
import { House, Search, Library, Puzzle, UserRound } from 'lucide-react-native';
const fg = '#B9C2D9';
export default function TabsLayout() {
  return <Tabs screenOptions={{ headerShown:false, tabBarStyle:{backgroundColor:'rgba(15,18,29,0.96)',borderTopColor:'rgba(255,255,255,0.1)',height:66,paddingTop:8,paddingBottom:8}, tabBarActiveTintColor:'#FFFFFF',tabBarInactiveTintColor:fg, tabBarLabelStyle:{fontSize:11} }}>
    <Tabs.Screen name="index" options={{title:'الرئيسية',tabBarIcon:({color,size})=><House color={color} size={size}/>}} />
    <Tabs.Screen name="discover" options={{title:'اكتشف',tabBarIcon:({color,size})=><Search color={color} size={size}/>}} />
    <Tabs.Screen name="library" options={{title:'مكتبتي',tabBarIcon:({color,size})=><Library color={color} size={size}/>}} />
    <Tabs.Screen name="addons" options={{title:'الإضافات',tabBarIcon:({color,size})=><Puzzle color={color} size={size}/>}} />
    <Tabs.Screen name="profile" options={{title:'حسابي',tabBarIcon:({color,size})=><UserRound color={color} size={size}/>}} />
  </Tabs>;
}
