# Cinema Glass (starter)

An Arabic RTL Android starter for a cinematic media discovery app. Includes a dark glass-style UI, basic TMDB trending/search integration, a preliminary Stremio manifest validator, and initial Supabase schema.

## Not yet implemented
- Google OAuth flow and account screens
- Supabase-backed library UI and progress synchronization
- Full playback flow and resume controls
- Complete Stremio resource client, repository indexes, source resolution and secure network policy
- Automated tests and production security review

Do not treat the starter as a complete streaming application or a production-ready APK.

## Setup
1. Install Node.js LTS and Android Studio / Android SDK.
2. Copy `.env.example` to `.env` and configure TMDB and Supabase values.
3. Run `npm install`.
4. Run `npx expo start` for development.
5. Apply `supabase/migrations/0001_initial.sql` to a test Supabase project before using private user data.

For an Android build, use a configured local Android SDK or EAS Build. Configure Google OAuth redirect URLs and Android package identifiers before testing login.

## Security notes
- `EXPO_PUBLIC_*` values are bundled into the client and are not secrets.
- Never place Supabase service-role keys in the app.
- The manifest validator is only a basic client-side check and is not a complete SSRF defense. Do not proxy arbitrary add-on URLs from a backend without strict network controls.
